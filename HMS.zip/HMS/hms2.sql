create database Rajesh2;
use Rajesh2;
-- Department Table
CREATE TABLE Department (
    departmentId BIGINT PRIMARY KEY,
    departmentName VARCHAR(100),
    location VARCHAR(100)
);

INSERT INTO Department VALUES
(1, 'Cardiology', 'Block A'),
(2, 'Orthopedics', 'Block B'),
(3, 'Pediatrics', 'Block C'),
(4, 'Neurology', 'Block D');

-- Patient Table
CREATE TABLE Patient (
    patientId BIGINT PRIMARY KEY,
    name VARCHAR(100),
    gender VARCHAR(50),
    contact BIGINT,
    address VARCHAR(150),
    email VARCHAR(100),
    bloodGroup VARCHAR(50),
    dob DATE,
    registrationDate DATE
);

INSERT INTO Patient VALUES
(11, 'Aarav Mehta', 'Male', 9876543210, 'Mumbai', 'aarav.mehta@gmail.com', 'B+', '2000-04-12', '2025-01-15'),
(12, 'Priya Sharma', 'Female', 9123456789, 'Delhi', 'priya.sharma@gmail.com', 'O-', '1995-07-22', '2025-02-01'),
(13, 'Ravi Kumar', 'Male', 9988776655, 'Chennai', 'ravi.kumar@gmail.com', 'A+', '1989-10-10', '2025-03-12'),
(14, 'Sneha Patil', 'Female', 9876012345, 'Pune', 'sneha.patil@gmail.com', 'AB-', '1998-01-30', '2025-04-25');

-- Doctor Table
CREATE TABLE Doctor (
    doctorId BIGINT PRIMARY KEY,
    name VARCHAR(100),
    specialization VARCHAR(100),
    contact BIGINT,
    email VARCHAR(100),
    departmentId BIGINT,
    joiningDate DATE,
    consultationFee DOUBLE,
    FOREIGN KEY (departmentId) REFERENCES Department(departmentId)
);

INSERT INTO Doctor VALUES
(21, 'Dr. Neha Reddy', 'Cardiologist', 9800011111, 'neha.reddy@hms.com', 1, '2020-05-10', 1000),
(22, 'Dr. Rajesh Iyer', 'Orthopedic', 9800022222, 'rajesh.iyer@hms.com', 2, '2018-03-15', 1200),
(23, 'Dr. Kavita Jain', 'Pediatrician', 9800033333, 'kavita.jain@hms.com', 3, '2019-07-20', 900),
(24, 'Dr. Arjun Menon', 'Neurologist', 9800044444, 'arjun.menon@hms.com', 4, '2021-01-05', 1500);

-- Appointment Table
CREATE TABLE Appointment (
    appointmentId BIGINT PRIMARY KEY,
    patientId BIGINT,
    doctorId BIGINT,
    appointmentDate DATE,
    appointmentTime TIME,
    FOREIGN KEY (patientId) REFERENCES Patient(patientId),
    FOREIGN KEY (doctorId) REFERENCES Doctor(doctorId)
);

INSERT INTO Appointment VALUES
(1, 11, 21, '2025-02-10', '10:30:00'),
(2, 12, 22, '2025-02-15', '11:00:00'),
(3, 13, 23, '2025-03-01', '09:45:00'),
(4, 14, 24, '2025-03-05', '14:00:00');

-- Bill Table
CREATE TABLE Bill (
    billId BIGINT PRIMARY KEY,
    patientId BIGINT,
    billDate DATE,
    billAmount BIGINT,
    paymentMode VARCHAR(100),
    status VARCHAR(100),
    FOREIGN KEY (patientId) REFERENCES Patient(patientId)
);

INSERT INTO Bill VALUES
(1, 11, '2025-02-10', 2000, 'Cash', 'Paid'),
(2, 12, '2025-02-15', 2500, 'Credit Card', 'Paid'),
(3, 13, '2025-03-01', 1800, 'UPI', 'Pending'),
(4, 14, '2025-03-05', 3000, 'Debit Card', 'Paid');

-- Nurse Table
CREATE TABLE Nurse (
    nurseId BIGINT PRIMARY KEY,
    departmentId BIGINT,
    name VARCHAR(100),
    contact BIGINT,
    shiftTimings TIME,
    FOREIGN KEY (departmentId) REFERENCES Department(departmentId)
);

INSERT INTO Nurse VALUES
(1, 1, 'Meena Das', 9811122233, '08:00:00'),
(2, 2, 'Kiran Patel', 9811133344, '10:00:00'),
(3, 3, 'Anita Rao', 9811144455, '12:00:00'),
(4, 4, 'Rita Singh', 9811155566, '14:00:00');

-- Prescription Table
CREATE TABLE Prescription (
    prescriptionId BIGINT PRIMARY KEY,
    patientId BIGINT,
    doctorId BIGINT,
    date DATE,
    medicineDetails VARCHAR(100),
    dosage VARCHAR(100),
    instructions VARCHAR(100),
    FOREIGN KEY (patientId) REFERENCES Patient(patientId),
    FOREIGN KEY (doctorId) REFERENCES Doctor(doctorId)
);

INSERT INTO Prescription VALUES
(1, 11, 21, '2025-02-10', 'Aspirin 100mg', '1 tablet/day', 'After meals'),
(2, 12, 22, '2025-02-15', 'Calcium D3', '2 tablets/day', 'After breakfast and dinner'),
(3, 13, 23, '2025-03-01', 'Paracetamol 500mg', '1 tablet/6hrs', 'With water'),
(4, 14, 24, '2025-03-05', 'Neurobion Forte', '1 tablet/day', 'After lunch');

-- Lab Report Table
CREATE TABLE LabReport (
    testId BIGINT PRIMARY KEY,
    patientId BIGINT,
    doctorId BIGINT,
    testType VARCHAR(100),
    testDate DATE,
    result VARCHAR(100),
    FOREIGN KEY (patientId) REFERENCES Patient(patientId),
    FOREIGN KEY (doctorId) REFERENCES Doctor(doctorId)
);

INSERT INTO LabReport VALUES
(1, 11, 21, 'Blood Test', '2025-02-10', 'Normal'),
(2, 12, 22, 'X-Ray', '2025-02-15', 'Fracture Detected'),
(3, 13, 23, 'Urine Test', '2025-03-01', 'Normal'),
(4, 14, 24, 'MRI Scan', '2025-03-05', 'Minor Issue');

-- Room Table
CREATE TABLE Room (
    roomId BIGINT PRIMARY KEY,
    roomType VARCHAR(100),
    roomCharges BIGINT,
    status VARCHAR(100)
);

INSERT INTO Room VALUES
(1, 'General Ward', 500, 'Available'),
(2, 'Private Room', 1500, 'Occupied'),
(3, 'ICU', 3000, 'Available'),
(4, 'Deluxe Room', 2500, 'Occupied');

-- Schedule Table
CREATE TABLE Schedule (
    nurseId BIGINT,
    startTime TIME,
    endTime TIME,
    notes VARCHAR(100),
    FOREIGN KEY (nurseId) REFERENCES Nurse(nurseId)
);

INSERT INTO Schedule VALUES
(1, '08:00:00', '14:00:00', 'Morning Shift'),
(2, '10:00:00', '16:00:00', 'Day Shift'),
(3, '12:00:00', '18:00:00', 'Evening Shift'),
(4, '14:00:00', '20:00:00', 'Night Shift');

SELECT *FROM Schedule;