package com.example.hms.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.example.hms.model.*;

public class HibernateUtil {

    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            // Load hibernate.cfg.xml
            Configuration cfg = new Configuration().configure();

            // Explicitly register all annotated entity classes
            cfg.addAnnotatedClass(Department.class);
            cfg.addAnnotatedClass(Doctor.class);
            cfg.addAnnotatedClass(Patient.class);
            cfg.addAnnotatedClass(Appointment.class);
            cfg.addAnnotatedClass(Bill.class);
            cfg.addAnnotatedClass(Nurse.class);
            cfg.addAnnotatedClass(Prescription.class);
            cfg.addAnnotatedClass(LabReport.class);
            cfg.addAnnotatedClass(Room.class);
            cfg.addAnnotatedClass(Schedule.class);

            // Build SessionFactory
            return cfg.buildSessionFactory(
                    new StandardServiceRegistryBuilder()
                            .applySettings(cfg.getProperties())
                            .build()
            );
        } catch (Throwable ex) {
            System.err.println("❌ SessionFactory creation failed: " + ex.getMessage());
            ex.printStackTrace();
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        getSessionFactory().close();
    }
}
