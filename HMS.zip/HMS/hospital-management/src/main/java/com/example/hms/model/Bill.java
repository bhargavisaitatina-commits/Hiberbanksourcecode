package com.example.hms.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "Bill")
public class Bill {
    @Id
    @Column(name = "billId")
    private Long billId;

    @ManyToOne
    @JoinColumn(name = "patientId")
    private Patient patient;

    @Column(name = "billDate")
    private LocalDate billDate;

    @Column(name = "billAmount")
    private Long billAmount;

    @Column(name = "paymentMode")
    private String paymentMode;

    @Column(name = "status")
    private String status;

    public Bill() {}

    public Long getBillId() {
        return billId;
    }

    public void setBillId(Long billId) {
        this.billId = billId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public LocalDate getBillDate() {
        return billDate;
    }

    public void setBillDate(LocalDate billDate) {
        this.billDate = billDate;
    }

    public Long getBillAmount() {
        return billAmount;
    }

    public void setBillAmount(Long billAmount) {
        this.billAmount = billAmount;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
