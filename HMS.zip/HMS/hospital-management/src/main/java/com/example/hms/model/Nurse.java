package com.example.hms.model;

import jakarta.persistence.*;
import java.time.LocalTime;
import java.util.List;

@Entity
@Table(name = "Nurse")
public class Nurse {
    @Id
    @Column(name = "nurseId")
    private Long nurseId;

    @ManyToOne
    @JoinColumn(name = "departmentId")
    private Department department;

    @Column(name = "name")
    private String name;

    @Column(name = "contact")
    private Long contact;

    // storing a single representative shift time as LocalTime (if schema uses different type adjust)
    @Column(name = "shiftTimings")
    private LocalTime shiftTimings;

    @OneToMany(mappedBy = "nurse", fetch = FetchType.LAZY)
    private List<Schedule> schedules;

    public Nurse() {}

    public Long getNurseId() {
        return nurseId;
    }

    public void setNurseId(Long nurseId) {
        this.nurseId = nurseId;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getContact() {
        return contact;
    }

    public void setContact(Long contact) {
        this.contact = contact;
    }

    public LocalTime getShiftTimings() {
        return shiftTimings;
    }

    public void setShiftTimings(LocalTime shiftTimings) {
        this.shiftTimings = shiftTimings;
    }

    public List<Schedule> getSchedules() {
        return schedules;
    }

    public void setSchedules(List<Schedule> schedules) {
        this.schedules = schedules;
    }
}
