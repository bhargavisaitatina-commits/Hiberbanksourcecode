package com.example.hms;

import com.example.hms.dao.GenericDao;
import com.example.hms.model.*;
import com.example.hms.util.HibernateUtil;
import org.hibernate.SessionFactory;
import java.util.List;

public class MainApp {

    public static void main(String[] args) {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        System.out.println("SessionFactory created: " + (sf != null));

        // Create DAOs for all tables
        GenericDao<Department, Long> deptDao = new GenericDao<>(Department.class);
        GenericDao<Doctor, Long> doctorDao = new GenericDao<>(Doctor.class);
        GenericDao<Patient, Long> patientDao = new GenericDao<>(Patient.class);
        GenericDao<Nurse, Long> nurseDao = new GenericDao<>(Nurse.class);
        GenericDao<Bill, Long> billDao = new GenericDao<>(Bill.class);
        GenericDao<Appointment, Long> appointmentDao = new GenericDao<>(Appointment.class);
        GenericDao<Prescription, Long> prescriptionDao = new GenericDao<>(Prescription.class);
        GenericDao<LabReport, Long> labReportDao = new GenericDao<>(LabReport.class);
        GenericDao<Room, Long> roomDao = new GenericDao<>(Room.class);
        GenericDao<Schedule, Schedule.ScheduleId> scheduleDao = new GenericDao<>(Schedule.class);

        System.out.println("\n==== Departments Table ====");
        List<Department> departments = deptDao.findAll();
        for (Department d : departments) {
            System.out.printf("%d | %s | %s%n", d.getDepartmentId(), d.getDepartmentName(), d.getLocation());
        }

        System.out.println("\n==== Doctors Table ====");
        List<Doctor> doctors = doctorDao.findAll();
        for (Doctor doc : doctors) {
            System.out.printf("%d | %s | %s | %s | %.2f%n",
                    doc.getDoctorId(),
                    doc.getName(),
                    doc.getSpecialization(),
                    doc.getEmail(),
                    doc.getConsultationFee() != null ? doc.getConsultationFee() : 0.0);
        }

        System.out.println("\n==== Patients Table ====");
        List<Patient> patients = patientDao.findAll();
        for (Patient p : patients) {
            System.out.printf("%d | %s | %s | %s | %s | %s%n",
                    p.getPatientId(),
                    p.getName(),
                    p.getEmail(),
                    p.getGender(),
                    p.getBloodGroup(),
                    p.getContact());
        }

        System.out.println("\n==== Nurses Table ====");
        List<Nurse> nurses = nurseDao.findAll();
        for (Nurse n : nurses) {
            System.out.printf("%d | %s | %s%n",
                    n.getNurseId(),
                    n.getName(),
                    n.getShiftTimings() != null ? n.getShiftTimings() : "N/A");
        }

        System.out.println("\n==== Bills Table ====");
        List<Bill> bills = billDao.findAll();
        for (Bill b : bills) {
            System.out.printf("%d | %s | %s | %d | %s%n",
                    b.getBillId(),
                    b.getBillDate(),
                    b.getPaymentMode(),
                    b.getBillAmount(),
                    b.getStatus());
        }

        System.out.println("\n==== Appointments Table ====");
        List<Appointment> appointments = appointmentDao.findAll();
        for (Appointment a : appointments) {
            System.out.printf("%d | %s | %s | %s%n",
                    a.getAppointmentId(),
                    a.getAppointmentDate(),
                    a.getAppointmentTime(),
                    a.getDoctor() != null ? a.getDoctor().getName() : "N/A");
        }

        System.out.println("\n==== Prescriptions Table ====");
        List<Prescription> prescriptions = prescriptionDao.findAll();
        for (Prescription pr : prescriptions) {
            System.out.printf("%d | %s | %s | %s%n",
                    pr.getPrescriptionId(),
                    pr.getDate(),
                    pr.getDosage(),
                    pr.getInstructions());
        }

        System.out.println("\n==== Lab Reports Table ====");
        List<LabReport> reports = labReportDao.findAll();
        for (LabReport lr : reports) {
            System.out.printf("%d | %s | %s | %s%n",
                    lr.getTestId(),
                    lr.getTestType(),
                    lr.getTestDate(),
                    lr.getResult());
        }

        System.out.println("\n==== Rooms Table ====");
        List<Room> rooms = roomDao.findAll();
        for (Room r : rooms) {
            System.out.printf("%d | %s | %d | %s%n",
                    r.getRoomId(),
                    r.getRoomType(),
                    r.getRoomCharges(),
                    r.getStatus());
        }

        System.out.println("\n==== Schedules Table ====");
        List<Schedule> schedules = scheduleDao.findAll();
        for (Schedule s : schedules) {
            System.out.printf("%d | %s | %s | %s%n",
                    s.getNurseId(),
                    s.getStartTime(),
                    s.getEndTime(),
                    s.getNotes());
        }

        HibernateUtil.shutdown();
    }
}
