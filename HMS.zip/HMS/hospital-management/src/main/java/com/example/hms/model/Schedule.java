package com.example.hms.model;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalTime;
import java.util.Objects;

@Entity
@Table(name = "Schedule")
@IdClass(Schedule.ScheduleId.class)
public class Schedule {

    @Id
    @Column(name = "nurseId")
    private Long nurseId;

    @Id
    @Column(name = "startTime")
    private LocalTime startTime;

    @Column(name = "endTime")
    private LocalTime endTime;

    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes;

    @ManyToOne
    @JoinColumn(name = "nurseId", insertable = false, updatable = false)
    private Nurse nurse;

    public Schedule() {}

    public Long getNurseId() {
        return nurseId;
    }

    public void setNurseId(Long nurseId) {
        this.nurseId = nurseId;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Nurse getNurse() {
        return nurse;
    }

    public void setNurse(Nurse nurse) {
        this.nurse = nurse;
    }

    // IdClass
    public static class ScheduleId implements Serializable {
        private Long nurseId;
        private LocalTime startTime;

        public ScheduleId() {}

        public ScheduleId(Long nurseId, LocalTime startTime) {
            this.nurseId = nurseId;
            this.startTime = startTime;
        }

        public Long getNurseId() {
            return nurseId;
        }

        public void setNurseId(Long nurseId) {
            this.nurseId = nurseId;
        }

        public LocalTime getStartTime() {
            return startTime;
        }

        public void setStartTime(LocalTime startTime) {
            this.startTime = startTime;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof ScheduleId)) return false;
            ScheduleId that = (ScheduleId) o;
            return Objects.equals(nurseId, that.nurseId) && Objects.equals(startTime, that.startTime);
        }

        @Override
        public int hashCode() {
            return Objects.hash(nurseId, startTime);
        }
    }
}
