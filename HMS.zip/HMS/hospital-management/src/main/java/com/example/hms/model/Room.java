package com.example.hms.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Room")
public class Room {
    @Id
    @Column(name = "roomId")
    private Long roomId;

    @Column(name = "roomType")
    private String roomType;

    @Column(name = "roomCharges")
    private Long roomCharges;

    @Column(name = "status")
    private String status;

    public Room() {}

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public Long getRoomCharges() {
        return roomCharges;
    }

    public void setRoomCharges(Long roomCharges) {
        this.roomCharges = roomCharges;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
